# -*- coding: utf-8 -*-
"""
Created on Fri Nov  8 10:24:53 2024

@author: X_FENG
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

cap=pd.read_csv("C:/Users/X_FENG/Desktop/lecture/2024-2025/Data Analysis_interview/data/cap.csv",index_col="Dates")
companies=pd.read_csv("C:/Users/X_FENG/Desktop/lecture/2024-2025/Data Analysis_interview/data/companies.csv", index_col="ticker")
restrictions=pd.read_csv("C:/Users/X_FENG/Desktop/lecture/2024-2025/Data Analysis_interview/data/restrictions.csv")
ret=pd.read_csv("C:/Users/X_FENG/Desktop/lecture/2024-2025/Data Analysis_interview/data/ret.csv",index_col="Dates")
vaccines=pd.read_csv("C:/Users/X_FENG/Desktop/lecture/2024-2025/Data Analysis_interview/data/vaccines.csv")
wgt=pd.read_csv("C:/Users/X_FENG/Desktop/lecture/2024-2025/Data Analysis_interview/data/wgt.csv",index_col="Dates")

cap.index=pd.to_datetime(cap.index)
ret.index=pd.to_datetime(ret.index)
wgt.index=pd.to_datetime(wgt.index)

cap.columns = pd.to_numeric(cap.columns)
ret.columns = pd.to_numeric(ret.columns)
wgt.columns = pd.to_numeric(wgt.columns)

# S1 - Descriptive statistics about companies information - country and industry
companies.groupby(["country"]).size().reset_index(name="count")
companies.groupby(["industry"]).size().reset_index(name="count")
crosstab=pd.crosstab(companies["country"], companies["industry"])

# S2 - Delete the company without clear industry
n_ins =companies[companies["industry"] == "???"].index
cap = cap.drop(columns = n_ins)
ret = ret.drop(columns = n_ins)
wgt = wgt.drop(columns = n_ins)

# S3 - calculate the average cummulative return for each country among first three days after (include) introducing the first vaccine
cty_list = companies["country"].unique()
vaccines["resultsDate"] = pd.to_datetime(vaccines["resultsDate"])
vac_date1 = min(vaccines["resultsDate"])
#vac_date3 = vac_date1 + pd.DateOffset(2)

ret_vac3 = ret.loc[(ret.index>=vac_date1),:].iloc[:3,:]

cum={}
for i in cty_list:
    com_i = companies[companies["country"] == i].index
    ret_i = ret_vac3.loc[:,ret_vac3.columns.isin(com_i)]
    
    cum[i] = ret_i.mean(axis=1).sum()
    
# S4 - calculate the cummulative weighted average return for each country between first restriction and last restriction 
restrictions["date_start"]=pd.to_datetime(restrictions["date_start"])
restrictions["date_end"] = pd.to_datetime(restrictions["date_end"])

restrict_date = restrictions.groupby("country").agg(start=("date_start", "min"), end=("date_end","max")).reset_index()

restrict_date['country'] = restrict_date['country'].replace("United Kingdom", "UK")

cum_ret = {}
avg_ret = {}
#wavg_ret = {}

for i in cty_list:
    com_i = companies[companies["country"] == i].index
    
    start_date = restrict_date.loc[restrict_date["country"] == i, "start"].iloc[0]
    end_date = restrict_date.loc[restrict_date["country"] == i, "end"].iloc[0]
    
    
    ret_i = ret.loc[(ret.index >= start_date) & (ret.index <= end_date),ret.columns.isin(com_i)]
    wgt_i = wgt.loc[(wgt.index >= start_date) & (wgt.index <= end_date),wgt.columns.isin(com_i)]
    
    wgt_scaled = wgt_i.div(wgt_i.sum(axis=1), axis=0) ####
    
    ret_wgt = ret_i * wgt_scaled
    
    wgtavg_ret = ret_wgt.sum(axis=1)
    
    cum_ret[i] = wgtavg_ret.sum(axis=0)
    avg_ret[i] = wgtavg_ret.mean(axis=0)
    #wavg_ret[i] = wgtavg_ret

# S5: plot weighted average return for each country
  wavg_ret = {}

  for i in cty_list:
      com_i = companies[companies["country"] == i].index
      
      ret_i = ret.loc[:,ret.columns.isin(com_i)]
      wgt_i = wgt.loc[:,wgt.columns.isin(com_i)]
      
      wgt_scaled = wgt_i.div(wgt_i.sum(axis=1), axis=0) #### divide each element by the row sum
      
      ret_wgt = ret_i * wgt_scaled
      
      wgtavg_ret = ret_wgt.sum(axis=1)
      
      wavg_ret[i] = wgtavg_ret

df = pd.DataFrame(wavg_ret).cumsum()

# Plotting the data
plt.figure(figsize=(10, 6))

# Plot each country's data
for country in df.columns:
    plt.plot(df.index, df[country], label=country)

# Adding labels and title
plt.xlabel('Date')
plt.ylabel('Data Value')
plt.title('Time Series Data for 5 Countries')
plt.legend(title='Countries')

# Show the plot
plt.xticks(rotation=45)  # Rotate x-axis labels for better readability
plt.tight_layout()  # Adjust layout to fit labels
plt.show()