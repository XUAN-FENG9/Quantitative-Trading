library(tidyverse)
library(quantmod)
cap=read.csv("C:/Users/X_FENG/Desktop/lecture/2024-2025/Data Analysis_interview/data/cap.csv")
companies=read.csv("C:/Users/X_FENG/Desktop/lecture/2024-2025/Data Analysis_interview/data/companies.csv")
restrictions=read.csv("C:/Users/X_FENG/Desktop/lecture/2024-2025/Data Analysis_interview/data/restrictions.csv")
ret=read.csv("C:/Users/X_FENG/Desktop/lecture/2024-2025/Data Analysis_interview/data/ret.csv")
vaccines=read.csv("C:/Users/X_FENG/Desktop/lecture/2024-2025/Data Analysis_interview/data/vaccines.csv")
wgt=read.csv("C:/Users/X_FENG/Desktop/lecture/2024-2025/Data Analysis_interview/data/wgt.csv")

cap$Dates=as.Date(cap$Dates)
ret$Dates=as.Date(ret$Dates)
wgt$Dates=as.Date(wgt$Dates)
restrictions$date_start=as.Date(restrictions$date_start)
restrictions$date_end = as.Date(restrictions$date_end)

cap=xts(cap[,-1],order.by = cap$Dates)
ret=xts(ret[,-1],order.by = ret$Dates)
wgt=xts(wgt[,-1],order.by = wgt$Dates)


colnames(cap) = 1:(ncol(cap))
colnames(ret) = 1:(ncol(ret))
colnames(wgt) = 1:(ncol(wgt))

# S1 - Descriptive statistics about companies information - country and industry
companies %>% count(country)
companies %>% count(industry)
companies %>% count(country, industry)

table(companies$country,companies$industry)

# S2 - Delete the company without clear industry
n_ins=which(companies$industry=="???")
cap=cap[, -which(names(cap)==n_ins)]
ret=ret[, -which(names(ret)==n_ins)]
wgt=wgt[, -which(names(wgt)==n_ins)]

# S3 - calculate the average cummulative return for each country among first three days after (include) introducing the first vaccine
vaccines$resultsDate=as.Date(vaccines$resultsDate)
vac_date1 = min(vaccines$resultsDate)
ret_vac3 = ret[which(index(ret) >= vac_date1),][1:3,]

#### solution1:
#ret_vac3 = data.frame(t(ret_vac3))
#ret_vac3$ticker = rownames(ret_vac3)
#ret_vac3 <- merge(ret_vac3, companies[, c("ticker", "country")], by.x = "ticker", by.y = "ticker", all = FALSE)  # inner join by default (only keep matching rows)
#summary1 = ret_vac3 %>% group_by(country) %>% summarize(across(where(is.numeric),mean)) 
#summary1 = summary1 %>% mutate(accu_ret = rowSums(across(where(is.numeric), na.rm=TRUE))

#### solution2:
cum = list()
for(i in unique(companies$country)) {
  # Get the tickers for the current country
  com_i <- companies %>% filter(country == i) %>% pull(ticker)
  ret_i <- ret_vac3[,colnames(ret_vac3) %in% com_i]
  
  avg_ret <- apply(ret_i, 1, mean)
  cum[i] <- sum(avg_ret)
}

# S4 - calculate the cummulative weighted average return for each country between first restriction and last restriction 
restrict_date = restrictions %>% group_by(country) %>% summarise(start = min(date_start), end = max(date_end, na.rm=TRUE))
restrict_date = restrict_date %>% mutate(country = ifelse(country == "United Kingdom", "UK", country))


# Initialize an empty data frame for cumulative returns
cum_ret <- list()
avg_ret <- list()

# Loop over each unique country
for(i in unique(companies$country)) {
  
  # Get the tickers for the current country
  com_i <- companies %>% filter(country == i) %>% pull(ticker)
  
  # Get the start and end dates for the current country from restrict_date
  start_date <- max(min(index(ret)), restrict_date$start[restrict_date$country == i])
  end_date <- min(max(index(ret)),restrict_date$end[restrict_date$country == i])
  
  # Filter `ret` based on the date range and company tickers
  ret_i <- ret[which(index(ret) >= start_date & index(ret) <= end_date), colnames(ret) %in% com_i]
  wgt_i <- wgt[which(index(wgt) >= start_date & index(wgt) <= end_date), colnames(ret) %in% com_i]
  
  # Scale the weights by dividing by row sums (normalize weights)
  
  wgt_scaled <- wgt_i / rowSums(wgt_i)
  
  # Calculate weighted returns
  ret_wgt <- ret_i * wgt_scaled
  
  # Calculate the average return for each day across all companies
  wgtavg_ret <- apply(ret_wgt, 1, sum)
  
  # Calculate the cumulative return for the country by summing up daily returns
  cum_ret[i] <- sum(wgtavg_ret)
  
  avg_ret[i] <- mean(wgtavg_ret)
  
}

result = data.frame(avg_ret=unlist(avg_ret), cum_ret=unlist(cum_ret))

# S5: plot weighted average return for each country
wavg_ret = list()

for(i in unique(companies$country)) {
  
  # Get the tickers for the current country
  com_i <- companies %>% filter(country == i) %>% pull(ticker)
  
  # Filter `ret` based on the date range and company tickers
  ret_i <- ret[, colnames(ret) %in% com_i]
  wgt_i <- wgt[, colnames(ret) %in% com_i]
  
  # Scale the weights by dividing by row sums (normalize weights)
  wgt_scaled <- wgt_i / apply(wgt_i, 1, sum)
  
  # Calculate weighted returns
  ret_wgt <- ret_i * wgt_scaled
  
  # Calculate the average return for each day across all companies
  wgtavg_ret <- apply(ret_wgt, 1, sum)
  
  wavg_ret[[i]] <- wgtavg_ret
  
}

dt=data.frame(wavg_ret)
cum=data.frame(apply(dt,2, cumsum))

# Plotting using matplot without reshaping to long format
matplot(x = as.Date(rownames(cum)), 
        y = cum, 
        type = "l",      # type "l" for lines
        col = 1:ncol(cum),  # different colors for each country
        lty = 1,         # line type (solid line)
        lwd = 2,         # line width
        xlab = "Date", 
        ylab = "Cumulative Return", 
        main = "Cumulative Returns by Country",
        xaxt = "n")      # suppress default x-axis

# Add custom x-axis labels (optional)
axis(1, at = as.Date(rownames(cum)), labels = rownames(cum), las = 2)

# Add a legend
legend("topright", legend = colnames(cum), 
       col = 1:ncol(cum), 
       lty = 1, 
       lwd = 2)





































































































